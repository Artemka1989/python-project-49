import prompt

name = prompt.string('May I have your name? ')


def welcome_user() -> object:

    print(f'Hello, {name}!')


welcome_user()
