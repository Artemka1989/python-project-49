# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*'],
 'brain_games': ['.git/*',
                 '.git/hooks/*',
                 '.git/info/*',
                 '.git/logs/*',
                 '.git/logs/refs/heads/*',
                 '.git/objects/0c/*',
                 '.git/objects/1a/*',
                 '.git/objects/28/*',
                 '.git/objects/49/*',
                 '.git/objects/4d/*',
                 '.git/objects/55/*',
                 '.git/objects/64/*',
                 '.git/objects/7f/*',
                 '.git/objects/a3/*',
                 '.git/objects/a7/*',
                 '.git/objects/d3/*',
                 '.git/objects/d5/*',
                 '.git/objects/e3/*',
                 '.git/objects/e6/*',
                 '.git/refs/heads/*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Artemka1989/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Artemka1989/python-project-49/actions)\n<a href="https://codeclimate.com/github/Artemka1989/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8ba36e38c6ba95520ab9/maintainability" /></a>\n',
    'author': 'Artemka1989',
    'author_email': 'kurnev.ar@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
